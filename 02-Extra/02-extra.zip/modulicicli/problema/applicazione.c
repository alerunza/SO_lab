#include "pippo.h"

int main() {
	f2(45);
}
