#include "pluto.h"

int f2(int g);
