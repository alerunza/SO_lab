#ifndef __PLUTO_H__
#define __PLUTO_H__

#include "pippo.h"

int f(int i);

#endif

