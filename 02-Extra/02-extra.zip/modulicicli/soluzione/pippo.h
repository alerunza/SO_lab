#ifndef __PIPPO_H__
#define __PIPPO_H__

#include "pluto.h"

int f2(int g);

#endif
