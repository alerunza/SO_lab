#include "pippo.h"

int main() {
	f2(45);
	f(89);
}
