#ifndef __PRODOTTO_H__
#define __PRODOTTO_H__

int moltiplica(int primo, int secondo);

#endif
