#include "somma.h"

int somma(int primo, int secondo) {

	return primo+secondo;  
}
