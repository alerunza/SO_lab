#include "prodotto.h"

int moltiplica(int primo, int secondo) {
	return primo*secondo;
}
