#ifndef __SOMMA_H__
#define __SOMMA_H__

int somma(int primo, int secondo);

#endif
